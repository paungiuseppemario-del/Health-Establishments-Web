# Design

## Behavioural design


TODO: Describe a concrete scenario for each use-case. 
Describe it in terms of interactions between the components introduces above, and the actors introduced in your requirements.

![Insert your Interaction/Sequence Diagrams for each use-case here.](images/design-healthestablishments.png)
## User Interface design
TODO: Specify and develop a user interface mockup using an HTML wireframe.

![Insert your wireframe screenshots for each use-case here](Finisheddesignhe.png)
TODO: repeat as necessary
